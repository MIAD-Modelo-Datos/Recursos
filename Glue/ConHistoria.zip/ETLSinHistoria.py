import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.dynamicframe import DynamicFrameCollection
from awsglue.dynamicframe import DynamicFrame

def handle_pickednulls(glueContext, dfc) -> DynamicFrameCollection:
    from pyspark.sql.functions import when
    df = dfc.select(list(dfc.keys())[0]).toDF()
    df = df.withColumn('pickedbypersonid', when(df['pickedbypersonid'] == 'NULL', '-1').otherwise(df['pickedbypersonid']))
    df = DynamicFrame.fromDF(df, glueContext, "pickers_fixed")
    return (DynamicFrameCollection({"CustomTransform0": df}, glueContext))
def get_picked_date_key(glueContext, dfc) -> DynamicFrameCollection:
    from pyspark.sql.functions import substring
    
    df = dfc.select(list(dfc.keys())[0]).toDF()
    #df = df.withColumn('picked_date_key', df['pickingcompletedwhen'].substring(0, 10))
    #df = df.withColumn('picked_date_key', df['pickingcompletedwhen'])
    df = df.withColumn('picked_date_key', substring('pickingcompletedwhen',0,10))
    df = DynamicFrame.fromDF(df, glueContext, "ordrers_with_picked_date_key")
    return (DynamicFrameCollection({"CustomTransform0": df}, glueContext))

## @params: [JOB_NAME]
args = getResolvedOptions(sys.argv, ['JOB_NAME'])

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args['JOB_NAME'], args)
## @type: DataSource
## @args: [database = "wideworldimporters", table_name = "application_people_csv", transformation_ctx = "DataSource10"]
## @return: DataSource10
## @inputs: []
DataSource10 = glueContext.create_dynamic_frame.from_catalog(database = "wideworldimporters", table_name = "application_people_csv", transformation_ctx = "DataSource10")
## @type: SelectFields
## @args: [paths = ["personid", "preferredname", "fullname", "issalesperson"], transformation_ctx = "Transform21"]
## @return: Transform21
## @inputs: [frame = DataSource10]
Transform21 = SelectFields.apply(frame = DataSource10, paths = ["personid", "preferredname", "fullname", "issalesperson"], transformation_ctx = "Transform21")
## @type: ApplyMapping
## @args: [mappings = [("personid", "long", "employee_key", "long"), ("fullname", "string", "employee", "string"), ("preferredname", "string", "preferred_name", "string"), ("issalesperson", "long", "is_salesperson", "boolean")], transformation_ctx = "Transform31"]
## @return: Transform31
## @inputs: [frame = Transform21]
Transform31 = ApplyMapping.apply(frame = Transform21, mappings = [("personid", "long", "employee_key", "long"), ("fullname", "string", "employee", "string"), ("preferredname", "string", "preferred_name", "string"), ("issalesperson", "long", "is_salesperson", "boolean")], transformation_ctx = "Transform31")
## @type: DataSink
## @args: [connection_type = "s3", format = "csv", connection_options = {"path": "s3://worldwideimportersdw/public_employee/", "partitionKeys": []}, transformation_ctx = "DataSink3"]
## @return: DataSink3
## @inputs: [frame = Transform31]
DataSink3 = glueContext.write_dynamic_frame.from_options(frame = Transform31, connection_type = "s3", format = "csv", connection_options = {"path": "s3://worldwideimportersdw/public_employee/", "partitionKeys": []}, transformation_ctx = "DataSink3")
## @type: DataSource
## @args: [database = "wideworldimporters", table_name = "application_stateprovinces_csv", transformation_ctx = "DataSource0"]
## @return: DataSource0
## @inputs: []
DataSource0 = glueContext.create_dynamic_frame.from_catalog(database = "wideworldimporters", table_name = "application_stateprovinces_csv", transformation_ctx = "DataSource0")
## @type: SelectFields
## @args: [paths = ["stateprovincename", "stateprovinceid", "countryid", "salesterritory"], transformation_ctx = "Transform6"]
## @return: Transform6
## @inputs: [frame = DataSource0]
Transform6 = SelectFields.apply(frame = DataSource0, paths = ["stateprovincename", "stateprovinceid", "countryid", "salesterritory"], transformation_ctx = "Transform6")
## @type: ApplyMapping
## @args: [mappings = [("stateprovinceid", "long", "r_stateprovinceid", "long"), ("stateprovincename", "string", "stateprovincename", "string"), ("countryid", "long", "countryid", "long"), ("salesterritory", "string", "salesterritory", "string")], transformation_ctx = "Transform24"]
## @return: Transform24
## @inputs: [frame = Transform6]
Transform24 = ApplyMapping.apply(frame = Transform6, mappings = [("stateprovinceid", "long", "r_stateprovinceid", "long"), ("stateprovincename", "string", "stateprovincename", "string"), ("countryid", "long", "countryid", "long"), ("salesterritory", "string", "salesterritory", "string")], transformation_ctx = "Transform24")
## @type: DataSource
## @args: [database = "wideworldimporters", table_name = "sales_customers_csv", transformation_ctx = "DataSource4"]
## @return: DataSource4
## @inputs: []
DataSource4 = glueContext.create_dynamic_frame.from_catalog(database = "wideworldimporters", table_name = "sales_customers_csv", transformation_ctx = "DataSource4")
## @type: DataSource
## @args: [database = "wideworldimporters", table_name = "warehouse_packagetypes_csv", transformation_ctx = "DataSource3"]
## @return: DataSource3
## @inputs: []
DataSource3 = glueContext.create_dynamic_frame.from_catalog(database = "wideworldimporters", table_name = "warehouse_packagetypes_csv", transformation_ctx = "DataSource3")
## @type: ApplyMapping
## @args: [mappings = [("packagetypeid", "long", "package_key", "long"), ("packagetypename", "string", "package", "string")], transformation_ctx = "Transform22"]
## @return: Transform22
## @inputs: [frame = DataSource3]
Transform22 = ApplyMapping.apply(frame = DataSource3, mappings = [("packagetypeid", "long", "package_key", "long"), ("packagetypename", "string", "package", "string")], transformation_ctx = "Transform22")
## @type: DataSink
## @args: [connection_type = "s3", format = "json", connection_options = {"path": "s3://worldwideimportersdw/public_package/", "partitionKeys": []}, transformation_ctx = "DataSink2"]
## @return: DataSink2
## @inputs: [frame = Transform22]
DataSink2 = glueContext.write_dynamic_frame.from_options(frame = Transform22, connection_type = "s3", format = "json", connection_options = {"path": "s3://worldwideimportersdw/public_package/", "partitionKeys": []}, transformation_ctx = "DataSink2")
## @type: ApplyMapping
## @args: [mappings = [("packagetypeid", "long", "r_packagetypeid", "long"), ("packagetypename", "string", "packagetypename", "string")], transformation_ctx = "Transform13"]
## @return: Transform13
## @inputs: [frame = DataSource3]
Transform13 = ApplyMapping.apply(frame = DataSource3, mappings = [("packagetypeid", "long", "r_packagetypeid", "long"), ("packagetypename", "string", "packagetypename", "string")], transformation_ctx = "Transform13")
## @type: DataSource
## @args: [database = "wideworldimporters", table_name = "sales_orderlines_csv", transformation_ctx = "DataSource2"]
## @return: DataSource2
## @inputs: []
DataSource2 = glueContext.create_dynamic_frame.from_catalog(database = "wideworldimporters", table_name = "sales_orderlines_csv", transformation_ctx = "DataSource2")
## @type: ApplyMapping
## @args: [mappings = [("orderlineid", "long", "orderlineid", "long"), ("orderid", "long", "r_orderid", "long"), ("stockitemid", "long", "stock_item_key", "long"), ("packagetypeid", "long", "package_key", "long"), ("quantity", "long", "quantity", "long"), ("unitprice", "double", "unitprice", "double"), ("taxrate", "double", "tax_amount", "double")], transformation_ctx = "Transform25"]
## @return: Transform25
## @inputs: [frame = DataSource2]
Transform25 = ApplyMapping.apply(frame = DataSource2, mappings = [("orderlineid", "long", "orderlineid", "long"), ("orderid", "long", "r_orderid", "long"), ("stockitemid", "long", "stock_item_key", "long"), ("packagetypeid", "long", "package_key", "long"), ("quantity", "long", "quantity", "long"), ("unitprice", "double", "unitprice", "double"), ("taxrate", "double", "tax_amount", "double")], transformation_ctx = "Transform25")
## @type: DataSource
## @args: [database = "wideworldimporters", table_name = "warehouse_stockitems_csv", transformation_ctx = "DataSource1"]
## @return: DataSource1
## @inputs: []
DataSource1 = glueContext.create_dynamic_frame.from_catalog(database = "wideworldimporters", table_name = "warehouse_stockitems_csv", transformation_ctx = "DataSource1")
## @type: SelectFields
## @args: [paths = ["stockitemid", "stockitemname", "supplierid", "colorid", "unitpackageid", "outerpackageid", "brand", "size", "leadtimedays", "quantityperouter", "ischillerstock", "barcode", "taxrate", "unitprice", "recommendedretailprice", "typicalweightperunit", "marketingcomments", "internalcomments", "photo", "customfields.CountryOfManufacture", "customfields.Tags", "customfields.MinimumAge", "customfields.Range", "customfields.ShelfLife", "tags", "searchdetails", "lasteditedby", "validfrom", "validto"], transformation_ctx = "Transform8"]
## @return: Transform8
## @inputs: [frame = DataSource1]
Transform8 = SelectFields.apply(frame = DataSource1, paths = ["stockitemid", "stockitemname", "supplierid", "colorid", "unitpackageid", "outerpackageid", "brand", "size", "leadtimedays", "quantityperouter", "ischillerstock", "barcode", "taxrate", "unitprice", "recommendedretailprice", "typicalweightperunit", "marketingcomments", "internalcomments", "photo", "customfields.CountryOfManufacture", "customfields.Tags", "customfields.MinimumAge", "customfields.Range", "customfields.ShelfLife", "tags", "searchdetails", "lasteditedby", "validfrom", "validto"], transformation_ctx = "Transform8")
## @type: DataSource
## @args: [database = "wideworldimporters", table_name = "dimension_date_csv", transformation_ctx = "DataSource8"]
## @return: DataSource8
## @inputs: []
DataSource8 = glueContext.create_dynamic_frame.from_catalog(database = "wideworldimporters", table_name = "dimension_date_csv", transformation_ctx = "DataSource8")
## @type: DataSink
## @args: [connection_type = "s3", format = "csv", connection_options = {"path": "s3://worldwideimportersdw/public_date_table/", "partitionKeys": []}, transformation_ctx = "DataSink5"]
## @return: DataSink5
## @inputs: [frame = DataSource8]
DataSink5 = glueContext.write_dynamic_frame.from_options(frame = DataSource8, connection_type = "s3", format = "csv", connection_options = {"path": "s3://worldwideimportersdw/public_date_table/", "partitionKeys": []}, transformation_ctx = "DataSink5")
## @type: DataSource
## @args: [database = "wideworldimporters", table_name = "sales_orders_csv", transformation_ctx = "DataSource7"]
## @return: DataSource7
## @inputs: []
DataSource7 = glueContext.create_dynamic_frame.from_catalog(database = "wideworldimporters", table_name = "sales_orders_csv", transformation_ctx = "DataSource7")
## @type: CustomCode
## @args: [dynamicFrameConstruction = DynamicFrameCollection({"DataSource7": DataSource7}, glueContext), className = handle_pickednulls, transformation_ctx = "Transform9"]
## @return: Transform9
## @inputs: [dfc = DataSource7]
Transform9 = handle_pickednulls(glueContext, DynamicFrameCollection({"DataSource7": DataSource7}, glueContext))
## @type: SelectFromCollection
## @args: [key = list(Transform9.keys())[0], transformation_ctx = "Transform3"]
## @return: Transform3
## @inputs: [dfc = Transform9]
Transform3 = SelectFromCollection.apply(dfc = Transform9, key = list(Transform9.keys())[0], transformation_ctx = "Transform3")
## @type: ApplyMapping
## @args: [mappings = [("orderid", "long", "order_key", "long"), ("customerid", "long", "customer_key", "long"), ("salespersonpersonid", "long", "salesperson_key", "long"), ("pickedbypersonid", "string", "picker_key", "long"), ("contactpersonid", "long", "contactpersonid", "long"), ("backorderorderid", "long", "backorderorderid", "long"), ("orderdate", "string", "order_date_key", "string"), ("expecteddeliverydate", "string", "expecteddeliverydate", "string"), ("pickingcompletedwhen", "string", "pickingcompletedwhen", "string")], transformation_ctx = "Transform14"]
## @return: Transform14
## @inputs: [frame = Transform3]
Transform14 = ApplyMapping.apply(frame = Transform3, mappings = [("orderid", "long", "order_key", "long"), ("customerid", "long", "customer_key", "long"), ("salespersonpersonid", "long", "salesperson_key", "long"), ("pickedbypersonid", "string", "picker_key", "long"), ("contactpersonid", "long", "contactpersonid", "long"), ("backorderorderid", "long", "backorderorderid", "long"), ("orderdate", "string", "order_date_key", "string"), ("expecteddeliverydate", "string", "expecteddeliverydate", "string"), ("pickingcompletedwhen", "string", "pickingcompletedwhen", "string")], transformation_ctx = "Transform14")
## @type: Join
## @args: [keys2 = ["r_orderid"], keys1 = ["order_key"], transformation_ctx = "Transform15"]
## @return: Transform15
## @inputs: [frame1 = Transform14, frame2 = Transform25]
Transform15 = Join.apply(frame1 = Transform14, frame2 = Transform25, keys2 = ["r_orderid"], keys1 = ["order_key"], transformation_ctx = "Transform15")
## @type: SelectFields
## @args: [paths = ["order_key", "customer_key", "salesperson_key", "contactpersonid", "backorderorderid", "order_date_key", "expecteddeliverydate", "pickingcompletedwhen", "package_key", "tax_amount", "stock_item_key", "quantity", "picker_key"], transformation_ctx = "Transform0"]
## @return: Transform0
## @inputs: [frame = Transform15]
Transform0 = SelectFields.apply(frame = Transform15, paths = ["order_key", "customer_key", "salesperson_key", "contactpersonid", "backorderorderid", "order_date_key", "expecteddeliverydate", "pickingcompletedwhen", "package_key", "tax_amount", "stock_item_key", "quantity", "picker_key"], transformation_ctx = "Transform0")
## @type: CustomCode
## @args: [dynamicFrameConstruction = DynamicFrameCollection({"Transform0": Transform0}, glueContext), className = get_picked_date_key, transformation_ctx = "Transform28"]
## @return: Transform28
## @inputs: [dfc = Transform0]
Transform28 = get_picked_date_key(glueContext, DynamicFrameCollection({"Transform0": Transform0}, glueContext))
## @type: SelectFromCollection
## @args: [key = list(Transform28.keys())[0], transformation_ctx = "Transform29"]
## @return: Transform29
## @inputs: [dfc = Transform28]
Transform29 = SelectFromCollection.apply(dfc = Transform28, key = list(Transform28.keys())[0], transformation_ctx = "Transform29")
## @type: Join
## @args: [keys2 = ["customer_key"], keys1 = ["customerid"], transformation_ctx = "Transform30"]
## @return: Transform30
## @inputs: [frame1 = DataSource4, frame2 = Transform29]
Transform30 = Join.apply(frame1 = DataSource4, frame2 = Transform29, keys2 = ["customer_key"], keys1 = ["customerid"], transformation_ctx = "Transform30")
## @type: DataSource
## @args: [database = "wideworldimporters", table_name = "application_countries_csv", transformation_ctx = "DataSource6"]
## @return: DataSource6
## @inputs: []
DataSource6 = glueContext.create_dynamic_frame.from_catalog(database = "wideworldimporters", table_name = "application_countries_csv", transformation_ctx = "DataSource6")
## @type: SelectFields
## @args: [paths = ["countryid", "countryname", "continent", "region", "subregion"], transformation_ctx = "Transform23"]
## @return: Transform23
## @inputs: [frame = DataSource6]
Transform23 = SelectFields.apply(frame = DataSource6, paths = ["countryid", "countryname", "continent", "region", "subregion"], transformation_ctx = "Transform23")
## @type: ApplyMapping
## @args: [mappings = [("countryid", "long", "r_ countryid", "long"), ("countryname", "string", "countryname", "string"), ("continent", "string", "continent", "string"), ("region", "string", "region", "string"), ("subregion", "string", "subregion", "string")], transformation_ctx = "Transform5"]
## @return: Transform5
## @inputs: [frame = Transform23]
Transform5 = ApplyMapping.apply(frame = Transform23, mappings = [("countryid", "long", "r_ countryid", "long"), ("countryname", "string", "countryname", "string"), ("continent", "string", "continent", "string"), ("region", "string", "region", "string"), ("subregion", "string", "subregion", "string")], transformation_ctx = "Transform5")
## @type: DataSource
## @args: [database = "wideworldimporters", table_name = "warehouse_colors_csv", transformation_ctx = "DataSource5"]
## @return: DataSource5
## @inputs: []
DataSource5 = glueContext.create_dynamic_frame.from_catalog(database = "wideworldimporters", table_name = "warehouse_colors_csv", transformation_ctx = "DataSource5")
## @type: ApplyMapping
## @args: [mappings = [("colorid", "long", "r_colorid", "long"), ("colorname", "string", "colorname", "string")], transformation_ctx = "Transform7"]
## @return: Transform7
## @inputs: [frame = DataSource5]
Transform7 = ApplyMapping.apply(frame = DataSource5, mappings = [("colorid", "long", "r_colorid", "long"), ("colorname", "string", "colorname", "string")], transformation_ctx = "Transform7")
## @type: Join
## @args: [keys2 = ["r_colorid"], keys1 = ["colorid"], transformation_ctx = "Transform10"]
## @return: Transform10
## @inputs: [frame1 = Transform8, frame2 = Transform7]
Transform10 = Join.apply(frame1 = Transform8, frame2 = Transform7, keys2 = ["r_colorid"], keys1 = ["colorid"], transformation_ctx = "Transform10")
## @type: ApplyMapping
## @args: [mappings = [("stockitemid", "long", "stockitemid", "long"), ("stockitemname", "string", "stockitemname", "string"), ("supplierid", "long", "supplierid", "long"), ("unitpackageid", "long", "unitpackageid", "long"), ("outerpackageid", "long", "outerpackageid", "long"), ("brand", "string", "brand", "string"), ("size", "string", "size", "string"), ("leadtimedays", "long", "leadtimedays", "long"), ("quantityperouter", "long", "quantityperouter", "long"), ("ischillerstock", "long", "ischillerstock", "long"), ("barcode", "long", "barcode", "long"), ("taxrate", "double", "taxrate", "double"), ("unitprice", "double", "unitprice", "double"), ("recommendedretailprice", "double", "recommendedretailprice", "double"), ("colorname", "string", "color", "string")], transformation_ctx = "Transform20"]
## @return: Transform20
## @inputs: [frame = Transform10]
Transform20 = ApplyMapping.apply(frame = Transform10, mappings = [("stockitemid", "long", "stockitemid", "long"), ("stockitemname", "string", "stockitemname", "string"), ("supplierid", "long", "supplierid", "long"), ("unitpackageid", "long", "unitpackageid", "long"), ("outerpackageid", "long", "outerpackageid", "long"), ("brand", "string", "brand", "string"), ("size", "string", "size", "string"), ("leadtimedays", "long", "leadtimedays", "long"), ("quantityperouter", "long", "quantityperouter", "long"), ("ischillerstock", "long", "ischillerstock", "long"), ("barcode", "long", "barcode", "long"), ("taxrate", "double", "taxrate", "double"), ("unitprice", "double", "unitprice", "double"), ("recommendedretailprice", "double", "recommendedretailprice", "double"), ("colorname", "string", "color", "string")], transformation_ctx = "Transform20")
## @type: Join
## @args: [keys2 = ["r_packagetypeid"], keys1 = ["unitpackageid"], transformation_ctx = "Transform2"]
## @return: Transform2
## @inputs: [frame1 = Transform20, frame2 = Transform13]
Transform2 = Join.apply(frame1 = Transform20, frame2 = Transform13, keys2 = ["r_packagetypeid"], keys1 = ["unitpackageid"], transformation_ctx = "Transform2")
## @type: ApplyMapping
## @args: [mappings = [("stockitemid", "long", "stock_item_key", "long"), ("stockitemname", "string", "stock_item", "string"), ("supplierid", "long", "supplierid", "long"), ("unitpackageid", "long", "unitpackageid", "long"), ("outerpackageid", "long", "outerpackageid", "long"), ("brand", "string", "brand", "string"), ("size", "string", "size", "string"), ("leadtimedays", "long", "leadtimedays", "long"), ("quantityperouter", "long", "quantityperouter", "long"), ("ischillerstock", "long", "ischillerstock", "long"), ("barcode", "long", "barcode", "long"), ("taxrate", "double", "taxrate", "double"), ("unitprice", "double", "unitprice", "double"), ("recommendedretailprice", "double", "recommendedretailprice", "double"), ("color", "string", "color", "string"), ("packagetypename", "string", "selling_package", "string")], transformation_ctx = "Transform4"]
## @return: Transform4
## @inputs: [frame = Transform2]
Transform4 = ApplyMapping.apply(frame = Transform2, mappings = [("stockitemid", "long", "stock_item_key", "long"), ("stockitemname", "string", "stock_item", "string"), ("supplierid", "long", "supplierid", "long"), ("unitpackageid", "long", "unitpackageid", "long"), ("outerpackageid", "long", "outerpackageid", "long"), ("brand", "string", "brand", "string"), ("size", "string", "size", "string"), ("leadtimedays", "long", "leadtimedays", "long"), ("quantityperouter", "long", "quantityperouter", "long"), ("ischillerstock", "long", "ischillerstock", "long"), ("barcode", "long", "barcode", "long"), ("taxrate", "double", "taxrate", "double"), ("unitprice", "double", "unitprice", "double"), ("recommendedretailprice", "double", "recommendedretailprice", "double"), ("color", "string", "color", "string"), ("packagetypename", "string", "selling_package", "string")], transformation_ctx = "Transform4")
## @type: Join
## @args: [keys2 = ["r_packagetypeid"], keys1 = ["outerpackageid"], transformation_ctx = "Transform16"]
## @return: Transform16
## @inputs: [frame1 = Transform4, frame2 = Transform13]
Transform16 = Join.apply(frame1 = Transform4, frame2 = Transform13, keys2 = ["r_packagetypeid"], keys1 = ["outerpackageid"], transformation_ctx = "Transform16")
## @type: ApplyMapping
## @args: [mappings = [("stock_item_key", "long", "stock_item_key", "long"), ("stock_item", "string", "stock_item", "string"), ("brand", "string", "brand", "string"), ("size", "string", "size_val", "string"), ("leadtimedays", "long", "lead_time_days", "long"), ("quantityperouter", "long", "quantity_per_outer", "long"), ("ischillerstock", "long", "is_chiller_stock", "long"), ("recommendedretailprice", "double", "recommended_retail_price", "double"), ("color", "string", "color", "string"), ("selling_package", "string", "selling_package", "string"), ("packagetypename", "string", "buying_package", "string")], transformation_ctx = "Transform17"]
## @return: Transform17
## @inputs: [frame = Transform16]
Transform17 = ApplyMapping.apply(frame = Transform16, mappings = [("stock_item_key", "long", "stock_item_key", "long"), ("stock_item", "string", "stock_item", "string"), ("brand", "string", "brand", "string"), ("size", "string", "size_val", "string"), ("leadtimedays", "long", "lead_time_days", "long"), ("quantityperouter", "long", "quantity_per_outer", "long"), ("ischillerstock", "long", "is_chiller_stock", "long"), ("recommendedretailprice", "double", "recommended_retail_price", "double"), ("color", "string", "color", "string"), ("selling_package", "string", "selling_package", "string"), ("packagetypename", "string", "buying_package", "string")], transformation_ctx = "Transform17")
## @type: DataSink
## @args: [connection_type = "s3", format = "csv", connection_options = {"path": "s3://worldwideimportersdw/public_stockitem/", "partitionKeys": []}, transformation_ctx = "DataSink1"]
## @return: DataSink1
## @inputs: [frame = Transform17]
DataSink1 = glueContext.write_dynamic_frame.from_options(frame = Transform17, connection_type = "s3", format = "csv", connection_options = {"path": "s3://worldwideimportersdw/public_stockitem/", "partitionKeys": []}, transformation_ctx = "DataSink1")
## @type: DataSource
## @args: [database = "wideworldimporters", table_name = "application_cities_csv", transformation_ctx = "DataSource9"]
## @return: DataSource9
## @inputs: []
DataSource9 = glueContext.create_dynamic_frame.from_catalog(database = "wideworldimporters", table_name = "application_cities_csv", transformation_ctx = "DataSource9")
## @type: SelectFields
## @args: [paths = ["cityid", "cityname", "stateprovinceid", "latestrecordedpopulation"], transformation_ctx = "Transform26"]
## @return: Transform26
## @inputs: [frame = DataSource9]
Transform26 = SelectFields.apply(frame = DataSource9, paths = ["cityid", "cityname", "stateprovinceid", "latestrecordedpopulation"], transformation_ctx = "Transform26")
## @type: Join
## @args: [keys2 = ["r_stateprovinceid"], keys1 = ["stateprovinceid"], transformation_ctx = "Transform27"]
## @return: Transform27
## @inputs: [frame1 = Transform26, frame2 = Transform24]
Transform27 = Join.apply(frame1 = Transform26, frame2 = Transform24, keys2 = ["r_stateprovinceid"], keys1 = ["stateprovinceid"], transformation_ctx = "Transform27")
## @type: ApplyMapping
## @args: [mappings = [("cityid", "long", "city_key", "long"), ("cityname", "string", "city", "string"), ("latestrecordedpopulation", "long", "latest_recorded_population", "long"), ("stateprovincename", "string", "state_province", "string"), ("countryid", "long", "countryid", "long"), ("salesterritory", "string", "sales_territory", "string")], transformation_ctx = "Transform11"]
## @return: Transform11
## @inputs: [frame = Transform27]
Transform11 = ApplyMapping.apply(frame = Transform27, mappings = [("cityid", "long", "city_key", "long"), ("cityname", "string", "city", "string"), ("latestrecordedpopulation", "long", "latest_recorded_population", "long"), ("stateprovincename", "string", "state_province", "string"), ("countryid", "long", "countryid", "long"), ("salesterritory", "string", "sales_territory", "string")], transformation_ctx = "Transform11")
## @type: Join
## @args: [keys2 = ["r_ countryid"], keys1 = ["countryid"], transformation_ctx = "Transform19"]
## @return: Transform19
## @inputs: [frame1 = Transform11, frame2 = Transform5]
Transform19 = Join.apply(frame1 = Transform11, frame2 = Transform5, keys2 = ["r_ countryid"], keys1 = ["countryid"], transformation_ctx = "Transform19")
## @type: ApplyMapping
## @args: [mappings = [("city_key", "long", "city_key", "long"), ("city", "string", "city", "string"), ("latest_recorded_population", "long", "latest_recorded_population", "long"), ("state_province", "string", "state_province", "string"), ("sales_territory", "string", "sales_territory", "string"), ("countryname", "string", "country", "string"), ("continent", "string", "continent", "string"), ("region", "string", "region", "string"), ("subregion", "string", "subregion", "string")], transformation_ctx = "Transform12"]
## @return: Transform12
## @inputs: [frame = Transform19]
Transform12 = ApplyMapping.apply(frame = Transform19, mappings = [("city_key", "long", "city_key", "long"), ("city", "string", "city", "string"), ("latest_recorded_population", "long", "latest_recorded_population", "long"), ("state_province", "string", "state_province", "string"), ("sales_territory", "string", "sales_territory", "string"), ("countryname", "string", "country", "string"), ("continent", "string", "continent", "string"), ("region", "string", "region", "string"), ("subregion", "string", "subregion", "string")], transformation_ctx = "Transform12")
## @type: Join
## @args: [keys2 = ["city_key"], keys1 = ["deliverycityid"], transformation_ctx = "Transform18"]
## @return: Transform18
## @inputs: [frame1 = Transform30, frame2 = Transform12]
Transform18 = Join.apply(frame1 = Transform30, frame2 = Transform12, keys2 = ["city_key"], keys1 = ["deliverycityid"], transformation_ctx = "Transform18")
## @type: SelectFields
## @args: [paths = ["city_key", "customer_key", "order_date_key", "order_key", "package_key", "picked_date_key", "picker_key", "quantity", "salesperson_key", "stock_item_key", "tax_amount"], transformation_ctx = "Transform1"]
## @return: Transform1
## @inputs: [frame = Transform18]
Transform1 = SelectFields.apply(frame = Transform18, paths = ["city_key", "customer_key", "order_date_key", "order_key", "package_key", "picked_date_key", "picker_key", "quantity", "salesperson_key", "stock_item_key", "tax_amount"], transformation_ctx = "Transform1")
## @type: DataSink
## @args: [connection_type = "s3", format = "csv", connection_options = {"path": "s3://worldwideimportersdw/public_fact_order/", "partitionKeys": []}, transformation_ctx = "DataSink4"]
## @return: DataSink4
## @inputs: [frame = Transform1]
DataSink4 = glueContext.write_dynamic_frame.from_options(frame = Transform1, connection_type = "s3", format = "csv", connection_options = {"path": "s3://worldwideimportersdw/public_fact_order/", "partitionKeys": []}, transformation_ctx = "DataSink4")
## @type: DataSink
## @args: [connection_type = "s3", format = "csv", connection_options = {"path": "s3://worldwideimportersdw/public_city/", "partitionKeys": []}, transformation_ctx = "DataSink0"]
## @return: DataSink0
## @inputs: [frame = Transform12]
DataSink0 = glueContext.write_dynamic_frame.from_options(frame = Transform12, connection_type = "s3", format = "csv", connection_options = {"path": "s3://worldwideimportersdw/public_city/", "partitionKeys": []}, transformation_ctx = "DataSink0")
job.commit()