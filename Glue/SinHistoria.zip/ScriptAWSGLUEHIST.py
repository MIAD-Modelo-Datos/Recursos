import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.dynamicframe import DynamicFrameCollection
from awsglue.dynamicframe import DynamicFrame
import re

def StockItemsDWGroupByMax(glueContext, dfc) -> DynamicFrameCollection:
    from pyspark.sql.window import Window
    from pyspark.sql.functions import rank, col
    df = dfc.select(list(dfc.keys())[0]).toDF()
    window = Window.partitionBy(df['wwi_stock_item_id']).orderBy(df['_version'].desc())
    df = df.select('*', rank().over(window).alias('rank')).filter(col('rank') == 1) 
    df = df.drop('rank')
    df = DynamicFrame.fromDF(df, glueContext, "StockItemsDWGroupByMax")
    return (DynamicFrameCollection({"StockItemsDWGroupByMax": df}, glueContext))
def TransformColorNull(glueContext, dfc) -> DynamicFrameCollection:
    from pyspark.sql.functions import when
    df = dfc.select(list(dfc.keys())[0]).toDF()
    df = df.withColumn('colorid', when(df['colorid'] == 'NULL', None).otherwise(df['colorid']))
    df = df.withColumn('colorid', df['colorid'].cast('bigint'))
    df = DynamicFrame.fromDF(df, glueContext, "colorid_fixed")
    return (DynamicFrameCollection({"CustomTransform1": df}, glueContext))
def handle_pickednulls(glueContext, dfc) -> DynamicFrameCollection:
    from pyspark.sql.functions import when
    df = dfc.select(list(dfc.keys())[0]).toDF()
    df = df.withColumn('pickedbypersonid', when(df['pickedbypersonid'] == 'NULL', '-1').otherwise(df['pickedbypersonid']))
    df = DynamicFrame.fromDF(df, glueContext, "pickers_fixed")
    return (DynamicFrameCollection({"CustomTransform0": df}, glueContext))
def get_picked_date_key(glueContext, dfc) -> DynamicFrameCollection:
    from pyspark.sql.functions import substring
    
    df = dfc.select(list(dfc.keys())[0]).toDF()
    #df = df.withColumn('picked_date_key', df['pickingcompletedwhen'].substring(0, 10))
    #df = df.withColumn('picked_date_key', df['pickingcompletedwhen'])
    df = df.withColumn('picked_date_key', substring('pickingcompletedwhen',0,10))
    df = DynamicFrame.fromDF(df, glueContext, "ordrers_with_picked_date_key")
    return (DynamicFrameCollection({"CustomTransform0": df}, glueContext))
def StockItemsTSVID(glueContext, dfc) -> DynamicFrameCollection:
    from pyspark.sql.functions import when, current_date, monotonically_increasing_id, to_date, lit
    df = dfc.select(list(dfc.keys())[0]).toDF()
    
    #Encontar máximo
    max_key = df.agg({"dw_stock_item_key": "max"}).collect()[0][0]
    
    if max_key is None:
        max_key = 1
    
    #cambio = 0, ya existía esa llave natural y no cambió.
    #cambio = 1, ya existía llave natural y cambió registro.
    #cambio = -1, no existía llave natural
    df = df.withColumn('cambio', when(df['dw_stock_item_key'].isNull(), -1).when((df['dw_stock_item_key'].isNotNull()) & ((df['color'] == df['dw_color']) | (df['color'].isNull() & df['color'].isNull())), 0).otherwise(1))
    
    #caso 0: Se quitan del df.
    df = df.where(df['cambio'] != 0)
    
    #Nuevos ids
    df = df.withColumn('new_id', monotonically_increasing_id() + max_key)
    
    #caso -1: Donde no se hizo el join (i.e, los registros transaccionales nuevos)
    df = df.withColumn('dw_version', when(df['cambio'] == -1, 1).otherwise(df['dw_version']))
    df = df.withColumn('dw_date_from', when(df['cambio'] == -1, current_date()).otherwise(df['dw_date_from']))
    df = df.withColumn('dw_date_to', when(df['cambio'] == -1, to_date(lit('2199-12-31'), 'yyyy-MM-dd')).otherwise(current_date()))
    df = df.withColumn('insert', when(df['cambio'] == -1, 1).otherwise(0))
    
    #caso 1:
    # 1.1 Es necesario editar existentes: poner dw_date_to como fecha actual. Después, actualizar en la base de datos (NO INSERTAR)
    # 1.2 Es necesario crear nueva fila, identica a anterior excepto que : _version = _version + 1, date_from = hoy, date_to = 2199-12-31
    df_dup = df.where(df['cambio'] == 1)
    #1.1
    #df = df.withColumn('dw_date_to',when(df['cambio'] == 1, current_date()))
    #df = df.withColumn('insert',when(df['cambio'] == 1, 0))
    #1.2
    df_dup = df_dup.withColumn('dw_version', df_dup['dw_version'] + 1)
    df_dup = df_dup.withColumn('dw_date_from', current_date())
    df_dup = df_dup.withColumn('dw_date_to', to_date(lit('2199-12-31'), 'yyyy-MM-dd'))
    #df_dup = df_dup.withColumn('dw_color', df_dup['color'])
    df_dup = df_dup.withColumn('insert',lit(1))
    
    
    #Juntar tablas
    df = df.union(df_dup)
    
    df = df.drop('cambio')
    
    df = DynamicFrame.fromDF(df, glueContext, "StockItemsTSVID")
    return (DynamicFrameCollection({"StockItemsTSVID": df}, glueContext))

## @params: [JOB_NAME]
args = getResolvedOptions(sys.argv, ['JOB_NAME'])

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args['JOB_NAME'], args)
## @type: DataSource
## @args: [database = "wideworldimportersdw", table_name = "wideworldimportersdw_dbo_stockitem_historia", transformation_ctx = "DataSource0"]
## @return: DataSource0
## @inputs: []
DataSource0 = glueContext.create_dynamic_frame.from_catalog(database = "wideworldimportersdw", table_name = "wideworldimportersdw_dbo_stockitem_historia", transformation_ctx = "DataSource0")
## @type: CustomCode
## @args: [dynamicFrameConstruction = DynamicFrameCollection({"DataSource0": DataSource0}, glueContext), className = StockItemsDWGroupByMax, transformation_ctx = "Transform23"]
## @return: Transform23
## @inputs: [dfc = DataSource0]
Transform23 = StockItemsDWGroupByMax(glueContext, DynamicFrameCollection({"DataSource0": DataSource0}, glueContext))
## @type: SelectFromCollection
## @args: [key = list(Transform23.keys())[0], transformation_ctx = "Transform4"]
## @return: Transform4
## @inputs: [dfc = Transform23]
Transform4 = SelectFromCollection.apply(dfc = Transform23, key = list(Transform23.keys())[0], transformation_ctx = "Transform4")
## @type: ApplyMapping
## @args: [mappings = [("_version", "int", "dw_version", "int"), ("color", "string", "dw_color", "string"), ("date_from", "date", "dw_date_from", "date"), ("wwi_stock_item_id", "int", "dw_wwi_stock_item_id", "int"), ("date_to", "date", "dw_date_to", "date"), ("stock_item_key", "long", "dw_stock_item_key", "long")], transformation_ctx = "Transform20"]
## @return: Transform20
## @inputs: [frame = Transform4]
Transform20 = ApplyMapping.apply(frame = Transform4, mappings = [("_version", "int", "dw_version", "int"), ("color", "string", "dw_color", "string"), ("date_from", "date", "dw_date_from", "date"), ("wwi_stock_item_id", "int", "dw_wwi_stock_item_id", "int"), ("date_to", "date", "dw_date_to", "date"), ("stock_item_key", "long", "dw_stock_item_key", "long")], transformation_ctx = "Transform20")
## @type: DataSource
## @args: [database = "wideworldimporters", table_name = "warehouse_packagetypes_csv", transformation_ctx = "DataSource4"]
## @return: DataSource4
## @inputs: []
DataSource4 = glueContext.create_dynamic_frame.from_catalog(database = "wideworldimporters", table_name = "warehouse_packagetypes_csv", transformation_ctx = "DataSource4")
## @type: ApplyMapping
## @args: [mappings = [("packagetypeid", "long", "r_packagetypeid", "long"), ("packagetypename", "string", "packagetypename", "string")], transformation_ctx = "Transform18"]
## @return: Transform18
## @inputs: [frame = DataSource4]
Transform18 = ApplyMapping.apply(frame = DataSource4, mappings = [("packagetypeid", "long", "r_packagetypeid", "long"), ("packagetypename", "string", "packagetypename", "string")], transformation_ctx = "Transform18")
## @type: ApplyMapping
## @args: [mappings = [("packagetypename", "string", "package", "string"), ("packagetypeid", "long", "package_key", "long")], transformation_ctx = "Transform31"]
## @return: Transform31
## @inputs: [frame = DataSource4]
Transform31 = ApplyMapping.apply(frame = DataSource4, mappings = [("packagetypename", "string", "package", "string"), ("packagetypeid", "long", "package_key", "long")], transformation_ctx = "Transform31")
## @type: DataSink
## @args: [database = "wideworldimportersdw", table_name = "wideworldimportersdw_dbo_public_package", transformation_ctx = "DataSink2"]
## @return: DataSink2
## @inputs: [frame = Transform31]
DataSink2 = glueContext.write_dynamic_frame.from_catalog(frame = Transform31, database = "wideworldimportersdw", table_name = "wideworldimportersdw_dbo_public_package", transformation_ctx = "DataSink2")
## @type: DataSource
## @args: [database = "wideworldimporters", table_name = "sales_orderlines_csv", transformation_ctx = "DataSource3"]
## @return: DataSource3
## @inputs: []
DataSource3 = glueContext.create_dynamic_frame.from_catalog(database = "wideworldimporters", table_name = "sales_orderlines_csv", transformation_ctx = "DataSource3")
## @type: ApplyMapping
## @args: [mappings = [("orderlineid", "long", "orderlineid", "long"), ("orderid", "long", "r_orderid", "long"), ("stockitemid", "long", "stock_item_key", "long"), ("packagetypeid", "long", "package_key", "long"), ("quantity", "long", "quantity", "long"), ("unitprice", "double", "unitprice", "double"), ("taxrate", "double", "tax_amount", "double")], transformation_ctx = "Transform35"]
## @return: Transform35
## @inputs: [frame = DataSource3]
Transform35 = ApplyMapping.apply(frame = DataSource3, mappings = [("orderlineid", "long", "orderlineid", "long"), ("orderid", "long", "r_orderid", "long"), ("stockitemid", "long", "stock_item_key", "long"), ("packagetypeid", "long", "package_key", "long"), ("quantity", "long", "quantity", "long"), ("unitprice", "double", "unitprice", "double"), ("taxrate", "double", "tax_amount", "double")], transformation_ctx = "Transform35")
## @type: DataSource
## @args: [database = "wideworldimporters", table_name = "warehouse_stockitems_incremental_csv", transformation_ctx = "DataSource2"]
## @return: DataSource2
## @inputs: []
DataSource2 = glueContext.create_dynamic_frame.from_catalog(database = "wideworldimporters", table_name = "warehouse_stockitems_incremental_csv", transformation_ctx = "DataSource2")
## @type: CustomCode
## @args: [dynamicFrameConstruction = DynamicFrameCollection({"DataSource2": DataSource2}, glueContext), className = TransformColorNull, transformation_ctx = "Transform10"]
## @return: Transform10
## @inputs: [dfc = DataSource2]
Transform10 = TransformColorNull(glueContext, DynamicFrameCollection({"DataSource2": DataSource2}, glueContext))
## @type: SelectFromCollection
## @args: [key = list(Transform10.keys())[0], transformation_ctx = "Transform34"]
## @return: Transform34
## @inputs: [dfc = Transform10]
Transform34 = SelectFromCollection.apply(dfc = Transform10, key = list(Transform10.keys())[0], transformation_ctx = "Transform34")
## @type: SelectFields
## @args: [paths = ["stockitemid", "stockitemname", "supplierid", "colorid", "unitpackageid", "outerpackageid", "brand", "size", "leadtimedays", "quantityperouter", "ischillerstock", "barcode", "taxrate", "unitprice", "recommendedretailprice", "typicalweightperunit", "marketingcomments", "internalcomments", "photo", "customfields.CountryOfManufacture", "customfields.Tags", "customfields.MinimumAge", "customfields.Range", "customfields.ShelfLife", "tags", "searchdetails", "lasteditedby", "validfrom", "validto"], transformation_ctx = "Transform11"]
## @return: Transform11
## @inputs: [frame = Transform34]
Transform11 = SelectFields.apply(frame = Transform34, paths = ["stockitemid", "stockitemname", "supplierid", "colorid", "unitpackageid", "outerpackageid", "brand", "size", "leadtimedays", "quantityperouter", "ischillerstock", "barcode", "taxrate", "unitprice", "recommendedretailprice", "typicalweightperunit", "marketingcomments", "internalcomments", "photo", "customfields.CountryOfManufacture", "customfields.Tags", "customfields.MinimumAge", "customfields.Range", "customfields.ShelfLife", "tags", "searchdetails", "lasteditedby", "validfrom", "validto"], transformation_ctx = "Transform11")
## @type: DataSource
## @args: [database = "wideworldimporters", table_name = "application_stateprovinces_csv", transformation_ctx = "DataSource1"]
## @return: DataSource1
## @inputs: []
DataSource1 = glueContext.create_dynamic_frame.from_catalog(database = "wideworldimporters", table_name = "application_stateprovinces_csv", transformation_ctx = "DataSource1")
## @type: SelectFields
## @args: [paths = ["stateprovincename", "stateprovinceid", "countryid", "salesterritory"], transformation_ctx = "Transform7"]
## @return: Transform7
## @inputs: [frame = DataSource1]
Transform7 = SelectFields.apply(frame = DataSource1, paths = ["stateprovincename", "stateprovinceid", "countryid", "salesterritory"], transformation_ctx = "Transform7")
## @type: ApplyMapping
## @args: [mappings = [("stateprovinceid", "long", "r_stateprovinceid", "long"), ("stateprovincename", "string", "stateprovincename", "string"), ("countryid", "long", "countryid", "long"), ("salesterritory", "string", "salesterritory", "string")], transformation_ctx = "Transform33"]
## @return: Transform33
## @inputs: [frame = Transform7]
Transform33 = ApplyMapping.apply(frame = Transform7, mappings = [("stateprovinceid", "long", "r_stateprovinceid", "long"), ("stateprovincename", "string", "stateprovincename", "string"), ("countryid", "long", "countryid", "long"), ("salesterritory", "string", "salesterritory", "string")], transformation_ctx = "Transform33")
## @type: DataSource
## @args: [database = "wideworldimporters", table_name = "sales_orders_csv", transformation_ctx = "DataSource8"]
## @return: DataSource8
## @inputs: []
DataSource8 = glueContext.create_dynamic_frame.from_catalog(database = "wideworldimporters", table_name = "sales_orders_csv", transformation_ctx = "DataSource8")
## @type: CustomCode
## @args: [dynamicFrameConstruction = DynamicFrameCollection({"DataSource8": DataSource8}, glueContext), className = handle_pickednulls, transformation_ctx = "Transform12"]
## @return: Transform12
## @inputs: [dfc = DataSource8]
Transform12 = handle_pickednulls(glueContext, DynamicFrameCollection({"DataSource8": DataSource8}, glueContext))
## @type: SelectFromCollection
## @args: [key = list(Transform12.keys())[0], transformation_ctx = "Transform3"]
## @return: Transform3
## @inputs: [dfc = Transform12]
Transform3 = SelectFromCollection.apply(dfc = Transform12, key = list(Transform12.keys())[0], transformation_ctx = "Transform3")
## @type: ApplyMapping
## @args: [mappings = [("orderid", "long", "order_key", "long"), ("customerid", "long", "customer_key", "long"), ("salespersonpersonid", "long", "salesperson_key", "long"), ("pickedbypersonid", "string", "pickedbypersonid", "string"), ("contactpersonid", "long", "contactpersonid", "long"), ("backorderorderid", "long", "backorderorderid", "long"), ("orderdate", "string", "order_date_key", "string"), ("expecteddeliverydate", "string", "expecteddeliverydate", "string"), ("pickingcompletedwhen", "string", "pickingcompletedwhen", "string")], transformation_ctx = "Transform19"]
## @return: Transform19
## @inputs: [frame = Transform3]
Transform19 = ApplyMapping.apply(frame = Transform3, mappings = [("orderid", "long", "order_key", "long"), ("customerid", "long", "customer_key", "long"), ("salespersonpersonid", "long", "salesperson_key", "long"), ("pickedbypersonid", "string", "pickedbypersonid", "string"), ("contactpersonid", "long", "contactpersonid", "long"), ("backorderorderid", "long", "backorderorderid", "long"), ("orderdate", "string", "order_date_key", "string"), ("expecteddeliverydate", "string", "expecteddeliverydate", "string"), ("pickingcompletedwhen", "string", "pickingcompletedwhen", "string")], transformation_ctx = "Transform19")
## @type: Join
## @args: [keys2 = ["r_orderid"], keys1 = ["order_key"], transformation_ctx = "Transform21"]
## @return: Transform21
## @inputs: [frame1 = Transform19, frame2 = Transform35]
Transform21 = Join.apply(frame1 = Transform19, frame2 = Transform35, keys2 = ["r_orderid"], keys1 = ["order_key"], transformation_ctx = "Transform21")
## @type: SelectFields
## @args: [paths = ["order_key", "customer_key", "salesperson_key", "contactpersonid", "backorderorderid", "order_date_key", "expecteddeliverydate", "pickingcompletedwhen", "package_key", "tax_amount", "stock_item_key", "quantity"], transformation_ctx = "Transform0"]
## @return: Transform0
## @inputs: [frame = Transform21]
Transform0 = SelectFields.apply(frame = Transform21, paths = ["order_key", "customer_key", "salesperson_key", "contactpersonid", "backorderorderid", "order_date_key", "expecteddeliverydate", "pickingcompletedwhen", "package_key", "tax_amount", "stock_item_key", "quantity"], transformation_ctx = "Transform0")
## @type: CustomCode
## @args: [dynamicFrameConstruction = DynamicFrameCollection({"Transform0": Transform0}, glueContext), className = get_picked_date_key, transformation_ctx = "Transform38"]
## @return: Transform38
## @inputs: [dfc = Transform0]
Transform38 = get_picked_date_key(glueContext, DynamicFrameCollection({"Transform0": Transform0}, glueContext))
## @type: SelectFromCollection
## @args: [key = list(Transform38.keys())[0], transformation_ctx = "Transform39"]
## @return: Transform39
## @inputs: [dfc = Transform38]
Transform39 = SelectFromCollection.apply(dfc = Transform38, key = list(Transform38.keys())[0], transformation_ctx = "Transform39")
## @type: DataSource
## @args: [database = "wideworldimporters", table_name = "application_countries_csv", transformation_ctx = "DataSource7"]
## @return: DataSource7
## @inputs: []
DataSource7 = glueContext.create_dynamic_frame.from_catalog(database = "wideworldimporters", table_name = "application_countries_csv", transformation_ctx = "DataSource7")
## @type: SelectFields
## @args: [paths = ["countryid", "countryname", "continent", "region", "subregion"], transformation_ctx = "Transform32"]
## @return: Transform32
## @inputs: [frame = DataSource7]
Transform32 = SelectFields.apply(frame = DataSource7, paths = ["countryid", "countryname", "continent", "region", "subregion"], transformation_ctx = "Transform32")
## @type: ApplyMapping
## @args: [mappings = [("countryid", "long", "r_ countryid", "long"), ("countryname", "string", "countryname", "string"), ("continent", "string", "continent", "string"), ("region", "string", "region", "string"), ("subregion", "string", "subregion", "string")], transformation_ctx = "Transform6"]
## @return: Transform6
## @inputs: [frame = Transform32]
Transform6 = ApplyMapping.apply(frame = Transform32, mappings = [("countryid", "long", "r_ countryid", "long"), ("countryname", "string", "countryname", "string"), ("continent", "string", "continent", "string"), ("region", "string", "region", "string"), ("subregion", "string", "subregion", "string")], transformation_ctx = "Transform6")
## @type: DataSource
## @args: [database = "wideworldimporters", table_name = "warehouse_colors_csv", transformation_ctx = "DataSource6"]
## @return: DataSource6
## @inputs: []
DataSource6 = glueContext.create_dynamic_frame.from_catalog(database = "wideworldimporters", table_name = "warehouse_colors_csv", transformation_ctx = "DataSource6")
## @type: ApplyMapping
## @args: [mappings = [("colorid", "long", "r_colorid", "long"), ("colorname", "string", "colorname", "string")], transformation_ctx = "Transform9"]
## @return: Transform9
## @inputs: [frame = DataSource6]
Transform9 = ApplyMapping.apply(frame = DataSource6, mappings = [("colorid", "long", "r_colorid", "long"), ("colorname", "string", "colorname", "string")], transformation_ctx = "Transform9")
## @type: Join
## @args: [columnConditions = ["="], joinType = left, keys2 = ["r_colorid"], keys1 = ["colorid"], transformation_ctx = "Transform14"]
## @return: Transform14
## @inputs: [frame1 = Transform11, frame2 = Transform9]
Transform11DF = Transform11.toDF()
Transform9DF = Transform9.toDF()
Transform14 = DynamicFrame.fromDF(Transform11DF.join(Transform9DF, (Transform11DF['colorid'] == Transform9DF['r_colorid']), "left"), glueContext, "Transform14")
## @type: ApplyMapping
## @args: [mappings = [("stockitemid", "long", "stockitemid", "long"), ("stockitemname", "string", "stockitemname", "string"), ("supplierid", "long", "supplierid", "long"), ("colorid", "bigint", "colorid", "bigint"), ("unitpackageid", "long", "unitpackageid", "long"), ("outerpackageid", "long", "outerpackageid", "long"), ("brand", "string", "brand", "string"), ("size", "string", "size", "string"), ("leadtimedays", "long", "leadtimedays", "long"), ("quantityperouter", "long", "quantityperouter", "long"), ("ischillerstock", "long", "ischillerstock", "long"), ("barcode", "long", "barcode", "long"), ("taxrate", "double", "taxrate", "double"), ("unitprice", "double", "unitprice", "double"), ("recommendedretailprice", "double", "recommendedretailprice", "double"), ("colorname", "string", "colorname", "string")], transformation_ctx = "Transform29"]
## @return: Transform29
## @inputs: [frame = Transform14]
Transform29 = ApplyMapping.apply(frame = Transform14, mappings = [("stockitemid", "long", "stockitemid", "long"), ("stockitemname", "string", "stockitemname", "string"), ("supplierid", "long", "supplierid", "long"), ("colorid", "bigint", "colorid", "bigint"), ("unitpackageid", "long", "unitpackageid", "long"), ("outerpackageid", "long", "outerpackageid", "long"), ("brand", "string", "brand", "string"), ("size", "string", "size", "string"), ("leadtimedays", "long", "leadtimedays", "long"), ("quantityperouter", "long", "quantityperouter", "long"), ("ischillerstock", "long", "ischillerstock", "long"), ("barcode", "long", "barcode", "long"), ("taxrate", "double", "taxrate", "double"), ("unitprice", "double", "unitprice", "double"), ("recommendedretailprice", "double", "recommendedretailprice", "double"), ("colorname", "string", "colorname", "string")], transformation_ctx = "Transform29")
## @type: Join
## @args: [keys2 = ["r_packagetypeid"], keys1 = ["unitpackageid"], transformation_ctx = "Transform2"]
## @return: Transform2
## @inputs: [frame1 = Transform29, frame2 = Transform18]
Transform2 = Join.apply(frame1 = Transform29, frame2 = Transform18, keys2 = ["r_packagetypeid"], keys1 = ["unitpackageid"], transformation_ctx = "Transform2")
## @type: ApplyMapping
## @args: [mappings = [("stockitemid", "long", "stock_item_key", "long"), ("stockitemname", "string", "stock_item", "string"), ("supplierid", "long", "supplierid", "long"), ("colorid", "bigint", "colorid", "bigint"), ("unitpackageid", "long", "unitpackageid", "long"), ("outerpackageid", "long", "outerpackageid", "long"), ("brand", "string", "brand", "string"), ("size", "string", "size", "string"), ("leadtimedays", "long", "leadtimedays", "long"), ("quantityperouter", "long", "quantityperouter", "long"), ("ischillerstock", "long", "ischillerstock", "long"), ("barcode", "long", "barcode", "long"), ("taxrate", "double", "taxrate", "double"), ("unitprice", "double", "unitprice", "double"), ("recommendedretailprice", "double", "recommendedretailprice", "double"), ("colorname", "string", "colorname", "string"), ("packagetypename", "string", "selling_package", "string")], transformation_ctx = "Transform5"]
## @return: Transform5
## @inputs: [frame = Transform2]
Transform5 = ApplyMapping.apply(frame = Transform2, mappings = [("stockitemid", "long", "stock_item_key", "long"), ("stockitemname", "string", "stock_item", "string"), ("supplierid", "long", "supplierid", "long"), ("colorid", "bigint", "colorid", "bigint"), ("unitpackageid", "long", "unitpackageid", "long"), ("outerpackageid", "long", "outerpackageid", "long"), ("brand", "string", "brand", "string"), ("size", "string", "size", "string"), ("leadtimedays", "long", "leadtimedays", "long"), ("quantityperouter", "long", "quantityperouter", "long"), ("ischillerstock", "long", "ischillerstock", "long"), ("barcode", "long", "barcode", "long"), ("taxrate", "double", "taxrate", "double"), ("unitprice", "double", "unitprice", "double"), ("recommendedretailprice", "double", "recommendedretailprice", "double"), ("colorname", "string", "colorname", "string"), ("packagetypename", "string", "selling_package", "string")], transformation_ctx = "Transform5")
## @type: Join
## @args: [keys2 = ["r_packagetypeid"], keys1 = ["outerpackageid"], transformation_ctx = "Transform24"]
## @return: Transform24
## @inputs: [frame1 = Transform5, frame2 = Transform18]
Transform24 = Join.apply(frame1 = Transform5, frame2 = Transform18, keys2 = ["r_packagetypeid"], keys1 = ["outerpackageid"], transformation_ctx = "Transform24")
## @type: ApplyMapping
## @args: [mappings = [("stock_item_key", "long", "stock_item_key", "long"), ("stock_item", "string", "stock_item", "string"), ("supplierid", "long", "supplierid", "long"), ("colorid", "bigint", "colorid", "bigint"), ("unitpackageid", "long", "unitpackageid", "long"), ("outerpackageid", "long", "outerpackageid", "long"), ("brand", "string", "brand", "string"), ("size", "string", "size_val", "string"), ("leadtimedays", "long", "lead_time_days", "byte"), ("quantityperouter", "long", "quantity_per_outer", "byte"), ("ischillerstock", "long", "is_chiller_stock", "byte"), ("barcode", "long", "barcode", "long"), ("taxrate", "double", "taxrate", "double"), ("unitprice", "double", "unitprice", "double"), ("recommendedretailprice", "double", "recommended_retail_price", "double"), ("colorname", "string", "color", "string"), ("selling_package", "string", "selling_package", "string"), ("r_packagetypeid", "long", "r_packagetypeid", "long"), ("packagetypename", "string", "buying_package", "string")], transformation_ctx = "Transform26"]
## @return: Transform26
## @inputs: [frame = Transform24]
Transform26 = ApplyMapping.apply(frame = Transform24, mappings = [("stock_item_key", "long", "stock_item_key", "long"), ("stock_item", "string", "stock_item", "string"), ("supplierid", "long", "supplierid", "long"), ("colorid", "bigint", "colorid", "bigint"), ("unitpackageid", "long", "unitpackageid", "long"), ("outerpackageid", "long", "outerpackageid", "long"), ("brand", "string", "brand", "string"), ("size", "string", "size_val", "string"), ("leadtimedays", "long", "lead_time_days", "byte"), ("quantityperouter", "long", "quantity_per_outer", "byte"), ("ischillerstock", "long", "is_chiller_stock", "byte"), ("barcode", "long", "barcode", "long"), ("taxrate", "double", "taxrate", "double"), ("unitprice", "double", "unitprice", "double"), ("recommendedretailprice", "double", "recommended_retail_price", "double"), ("colorname", "string", "color", "string"), ("selling_package", "string", "selling_package", "string"), ("r_packagetypeid", "long", "r_packagetypeid", "long"), ("packagetypename", "string", "buying_package", "string")], transformation_ctx = "Transform26")
## @type: Join
## @args: [columnConditions = ["="], joinType = left, keys2 = ["dw_wwi_stock_item_id"], keys1 = ["stock_item_key"], transformation_ctx = "Transform44"]
## @return: Transform44
## @inputs: [frame1 = Transform26, frame2 = Transform20]
Transform26DF = Transform26.toDF()
Transform20DF = Transform20.toDF()
Transform44 = DynamicFrame.fromDF(Transform26DF.join(Transform20DF, (Transform26DF['stock_item_key'] == Transform20DF['dw_wwi_stock_item_id']), "left"), glueContext, "Transform44")
## @type: CustomCode
## @args: [dynamicFrameConstruction = DynamicFrameCollection({"Transform44": Transform44}, glueContext), className = StockItemsTSVID, transformation_ctx = "Transform43"]
## @return: Transform43
## @inputs: [dfc = Transform44]
Transform43 = StockItemsTSVID(glueContext, DynamicFrameCollection({"Transform44": Transform44}, glueContext))
## @type: SelectFromCollection
## @args: [key = list(Transform43.keys())[0], transformation_ctx = "Transform13"]
## @return: Transform13
## @inputs: [dfc = Transform43]
Transform13 = SelectFromCollection.apply(dfc = Transform43, key = list(Transform43.keys())[0], transformation_ctx = "Transform13")
## @type: Filter
## @args: [f = lambda row : (row["insert"] == 1), transformation_ctx = "Transform17"]
## @return: Transform17
## @inputs: [frame = Transform13]
Transform17 = Filter.apply(frame = Transform13, f = lambda row : (row["insert"] == 1), transformation_ctx = "Transform17")
## @type: ApplyMapping
## @args: [mappings = [("dw_version", "int", "_version", "int"), ("is_chiller_stock", "byte", "is_chiller_stock", "byte"), ("recommended_retail_price", "double", "recommended_retail_price", "decimal"), ("color", "string", "color", "string"), ("stock_item", "string", "stock_item", "string"), ("dw_date_from", "date", "date_from", "date"), ("brand", "string", "brand", "string"), ("stock_item_key", "long", "wwi_stock_item_id", "int"), ("dw_date_to", "date", "date_to", "date"), ("size_val", "string", "size_val", "string"), ("selling_package", "string", "selling_package", "string"), ("new_id", "bigint", "stock_item_key", "long"), ("buying_package", "string", "buying_package", "string"), ("quantity_per_outer", "byte", "quantity_per_outer", "int"), ("lead_time_days", "byte", "lead_time_days", "int")], transformation_ctx = "Transform22"]
## @return: Transform22
## @inputs: [frame = Transform17]
Transform22 = ApplyMapping.apply(frame = Transform17, mappings = [("dw_version", "int", "_version", "int"), ("is_chiller_stock", "byte", "is_chiller_stock", "byte"), ("recommended_retail_price", "double", "recommended_retail_price", "decimal"), ("color", "string", "color", "string"), ("stock_item", "string", "stock_item", "string"), ("dw_date_from", "date", "date_from", "date"), ("brand", "string", "brand", "string"), ("stock_item_key", "long", "wwi_stock_item_id", "int"), ("dw_date_to", "date", "date_to", "date"), ("size_val", "string", "size_val", "string"), ("selling_package", "string", "selling_package", "string"), ("new_id", "bigint", "stock_item_key", "long"), ("buying_package", "string", "buying_package", "string"), ("quantity_per_outer", "byte", "quantity_per_outer", "int"), ("lead_time_days", "byte", "lead_time_days", "int")], transformation_ctx = "Transform22")
## @type: DataSink
## @args: [database = "wideworldimportersdw", table_name = "wideworldimportersdw_dbo_stockitem_historia", transformation_ctx = "DataSink5"]
## @return: DataSink5
## @inputs: [frame = Transform22]
DataSink5 = glueContext.write_dynamic_frame.from_catalog(frame = Transform22, database = "wideworldimportersdw", table_name = "wideworldimportersdw_dbo_stockitem_historia", transformation_ctx = "DataSink5")
## @type: Filter
## @args: [f = lambda row : (row["insert"] == 0), transformation_ctx = "Transform8"]
## @return: Transform8
## @inputs: [frame = Transform13]
Transform8 = Filter.apply(frame = Transform13, f = lambda row : (row["insert"] == 0), transformation_ctx = "Transform8")
## @type: ApplyMapping
## @args: [mappings = [("dw_stock_item_key", "bigint", "stock_item_key", "long"), ("dw_date_to", "date", "date_to", "date")], transformation_ctx = "Transform42"]
## @return: Transform42
## @inputs: [frame = Transform8]
Transform42 = ApplyMapping.apply(frame = Transform8, mappings = [("dw_stock_item_key", "bigint", "stock_item_key", "long"), ("dw_date_to", "date", "date_to", "date")], transformation_ctx = "Transform42")
## @type: DataSink
## @args: [database = "wideworldimportersdw", table_name = "wideworldimportersdw_dbo_stockitem_historia_update", transformation_ctx = "DataSink3"]
## @return: DataSink3
## @inputs: [frame = Transform42]
DataSink3 = glueContext.write_dynamic_frame.from_catalog(frame = Transform42, database = "wideworldimportersdw", table_name = "wideworldimportersdw_dbo_stockitem_historia_update", transformation_ctx = "DataSink3")
## @type: DataSource
## @args: [database = "wideworldimporters", table_name = "sales_customers_csv", transformation_ctx = "DataSource5"]
## @return: DataSource5
## @inputs: []
DataSource5 = glueContext.create_dynamic_frame.from_catalog(database = "wideworldimporters", table_name = "sales_customers_csv", transformation_ctx = "DataSource5")
## @type: Join
## @args: [keys2 = ["customer_key"], keys1 = ["customerid"], transformation_ctx = "Transform40"]
## @return: Transform40
## @inputs: [frame1 = DataSource5, frame2 = Transform39]
Transform40 = Join.apply(frame1 = DataSource5, frame2 = Transform39, keys2 = ["customer_key"], keys1 = ["customerid"], transformation_ctx = "Transform40")
## @type: DataSource
## @args: [database = "wideworldimporters", table_name = "dimension_date_csv", transformation_ctx = "DataSource9"]
## @return: DataSource9
## @inputs: []
DataSource9 = glueContext.create_dynamic_frame.from_catalog(database = "wideworldimporters", table_name = "dimension_date_csv", transformation_ctx = "DataSource9")
## @type: ApplyMapping
## @args: [mappings = [("date", "string", "date", "date"), ("calendar month number", "long", "calendar_month_number", "int"), ("fiscal month label", "string", "fiscal_month_label", "string"), ("calendar year label", "string", "calendar_year_label", "string"), ("fiscal year label", "string", "fiscal_year_label", "string"), ("fiscal month number", "long", "fiscal_month_number", "int"), ("day", "long", "iso_week_number", "int"), ("month", "string", "month", "string"), ("short month", "string", "fiscal_year", "int"), ("day number", "long", "day_number", "int"), ("calendar year", "long", "calendar_year", "int"), ("day", "long", "day", "int")], transformation_ctx = "Transform25"]
## @return: Transform25
## @inputs: [frame = DataSource9]
Transform25 = ApplyMapping.apply(frame = DataSource9, mappings = [("date", "string", "date", "date"), ("calendar month number", "long", "calendar_month_number", "int"), ("fiscal month label", "string", "fiscal_month_label", "string"), ("calendar year label", "string", "calendar_year_label", "string"), ("fiscal year label", "string", "fiscal_year_label", "string"), ("fiscal month number", "long", "fiscal_month_number", "int"), ("day", "long", "iso_week_number", "int"), ("month", "string", "month", "string"), ("short month", "string", "fiscal_year", "int"), ("day number", "long", "day_number", "int"), ("calendar year", "long", "calendar_year", "int"), ("day", "long", "day", "int")], transformation_ctx = "Transform25")
## @type: DataSink
## @args: [database = "wideworldimportersdw", table_name = "wideworldimportersdw_dbo_public_date_table", transformation_ctx = "DataSink1"]
## @return: DataSink1
## @inputs: [frame = Transform25]
DataSink1 = glueContext.write_dynamic_frame.from_catalog(frame = Transform25, database = "wideworldimportersdw", table_name = "wideworldimportersdw_dbo_public_date_table", transformation_ctx = "DataSink1")
## @type: DataSource
## @args: [database = "wideworldimporters", table_name = "application_people_csv", transformation_ctx = "DataSource11"]
## @return: DataSource11
## @inputs: []
DataSource11 = glueContext.create_dynamic_frame.from_catalog(database = "wideworldimporters", table_name = "application_people_csv", transformation_ctx = "DataSource11")
## @type: SelectFields
## @args: [paths = ["personid", "preferredname", "fullname", "issalesperson"], transformation_ctx = "Transform30"]
## @return: Transform30
## @inputs: [frame = DataSource11]
Transform30 = SelectFields.apply(frame = DataSource11, paths = ["personid", "preferredname", "fullname", "issalesperson"], transformation_ctx = "Transform30")
## @type: ApplyMapping
## @args: [mappings = [("personid", "long", "employee_key", "long"), ("fullname", "string", "employee", "string"), ("preferredname", "string", "preferred_name", "string"), ("issalesperson", "long", "is_salesperson", "boolean")], transformation_ctx = "Transform41"]
## @return: Transform41
## @inputs: [frame = Transform30]
Transform41 = ApplyMapping.apply(frame = Transform30, mappings = [("personid", "long", "employee_key", "long"), ("fullname", "string", "employee", "string"), ("preferredname", "string", "preferred_name", "string"), ("issalesperson", "long", "is_salesperson", "boolean")], transformation_ctx = "Transform41")
## @type: DataSink
## @args: [database = "wideworldimportersdw", table_name = "wideworldimportersdw_dbo_public_employee", transformation_ctx = "DataSink4"]
## @return: DataSink4
## @inputs: [frame = Transform41]
DataSink4 = glueContext.write_dynamic_frame.from_catalog(frame = Transform41, database = "wideworldimportersdw", table_name = "wideworldimportersdw_dbo_public_employee", transformation_ctx = "DataSink4")
## @type: DataSource
## @args: [database = "wideworldimporters", table_name = "application_cities_csv", transformation_ctx = "DataSource10"]
## @return: DataSource10
## @inputs: []
DataSource10 = glueContext.create_dynamic_frame.from_catalog(database = "wideworldimporters", table_name = "application_cities_csv", transformation_ctx = "DataSource10")
## @type: SelectFields
## @args: [paths = ["cityid", "cityname", "stateprovinceid", "latestrecordedpopulation"], transformation_ctx = "Transform36"]
## @return: Transform36
## @inputs: [frame = DataSource10]
Transform36 = SelectFields.apply(frame = DataSource10, paths = ["cityid", "cityname", "stateprovinceid", "latestrecordedpopulation"], transformation_ctx = "Transform36")
## @type: Join
## @args: [keys2 = ["r_stateprovinceid"], keys1 = ["stateprovinceid"], transformation_ctx = "Transform37"]
## @return: Transform37
## @inputs: [frame1 = Transform36, frame2 = Transform33]
Transform37 = Join.apply(frame1 = Transform36, frame2 = Transform33, keys2 = ["r_stateprovinceid"], keys1 = ["stateprovinceid"], transformation_ctx = "Transform37")
## @type: ApplyMapping
## @args: [mappings = [("cityid", "long", "city_key", "long"), ("cityname", "string", "city", "string"), ("latestrecordedpopulation", "long", "latest_recorded_population", "long"), ("stateprovincename", "string", "state_province", "string"), ("countryid", "long", "countryid", "long"), ("salesterritory", "string", "sales_territory", "string")], transformation_ctx = "Transform15"]
## @return: Transform15
## @inputs: [frame = Transform37]
Transform15 = ApplyMapping.apply(frame = Transform37, mappings = [("cityid", "long", "city_key", "long"), ("cityname", "string", "city", "string"), ("latestrecordedpopulation", "long", "latest_recorded_population", "long"), ("stateprovincename", "string", "state_province", "string"), ("countryid", "long", "countryid", "long"), ("salesterritory", "string", "sales_territory", "string")], transformation_ctx = "Transform15")
## @type: Join
## @args: [keys2 = ["r_ countryid"], keys1 = ["countryid"], transformation_ctx = "Transform28"]
## @return: Transform28
## @inputs: [frame1 = Transform15, frame2 = Transform6]
Transform28 = Join.apply(frame1 = Transform15, frame2 = Transform6, keys2 = ["r_ countryid"], keys1 = ["countryid"], transformation_ctx = "Transform28")
## @type: ApplyMapping
## @args: [mappings = [("continent", "string", "continent", "string"), ("city_key", "long", "city_key", "long"), ("countryname", "string", "country", "string"), ("latest_recorded_population", "long", "latest_recorded_population", "string"), ("city", "string", "city", "string"), ("subregion", "string", "subregion", "string"), ("state_province", "string", "state_province", "string"), ("region", "string", "region", "string"), ("sales_territory", "string", "sales_territory", "string")], transformation_ctx = "Transform16"]
## @return: Transform16
## @inputs: [frame = Transform28]
Transform16 = ApplyMapping.apply(frame = Transform28, mappings = [("continent", "string", "continent", "string"), ("city_key", "long", "city_key", "long"), ("countryname", "string", "country", "string"), ("latest_recorded_population", "long", "latest_recorded_population", "string"), ("city", "string", "city", "string"), ("subregion", "string", "subregion", "string"), ("state_province", "string", "state_province", "string"), ("region", "string", "region", "string"), ("sales_territory", "string", "sales_territory", "string")], transformation_ctx = "Transform16")
## @type: DataSink
## @args: [database = "wideworldimportersdw", table_name = "wideworldimportersdw_dbo_public_city", transformation_ctx = "DataSink6"]
## @return: DataSink6
## @inputs: [frame = Transform16]
DataSink6 = glueContext.write_dynamic_frame.from_catalog(frame = Transform16, database = "wideworldimportersdw", table_name = "wideworldimportersdw_dbo_public_city", transformation_ctx = "DataSink6")
## @type: Join
## @args: [keys2 = ["city_key"], keys1 = ["deliverycityid"], transformation_ctx = "Transform27"]
## @return: Transform27
## @inputs: [frame1 = Transform40, frame2 = Transform16]
Transform27 = Join.apply(frame1 = Transform40, frame2 = Transform16, keys2 = ["city_key"], keys1 = ["deliverycityid"], transformation_ctx = "Transform27")
## @type: SelectFields
## @args: [paths = ["city_key", "customer_key", "order_date_key", "order_key", "package_key", "picked_date_key", "picker_key", "quantity", "salesperson_key", "stock_item_key", "tax_amount"], transformation_ctx = "Transform1"]
## @return: Transform1
## @inputs: [frame = Transform27]
Transform1 = SelectFields.apply(frame = Transform27, paths = ["city_key", "customer_key", "order_date_key", "order_key", "package_key", "picked_date_key", "picker_key", "quantity", "salesperson_key", "stock_item_key", "tax_amount"], transformation_ctx = "Transform1")
## @type: DataSink
## @args: [database = "wideworldimportersdw", table_name = "wideworldimportersdw_dbo_public_fact_order", transformation_ctx = "DataSink0"]
## @return: DataSink0
## @inputs: [frame = Transform1]
DataSink0 = glueContext.write_dynamic_frame.from_catalog(frame = Transform1, database = "wideworldimportersdw", table_name = "wideworldimportersdw_dbo_public_fact_order", transformation_ctx = "DataSink0")
job.commit()
